package com.samsung.spenemulatorlibrary;

import java.util.HashMap;

import android.app.Activity;
import android.graphics.Color;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.MotionEvent.PointerCoords;
import android.view.MotionEvent.PointerProperties;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;

public abstract class ActivityWithSPenLayer extends Activity {

	/**
	 * Static value that determines finger.
	 */
	private static final int FINGER = 0;
	/**
	 * Static value that determines stylus.
	 */
	private static final int PEN_TOUCH = 1;
	/**
	 * Static value that determines pen eraser.
	 */
	private static final int ERASER = 2;
	/**
	 * Static value that determines pen hovering.
	 */
	private static final int PEN_HOVER = 3;
	/**
	 * Static value of the numeric 4 button, used as substitute for spen side button for emulator.
	 */
	private static final int NUMERIC4 = 21;
	/**
	 * String for menu.
	 */
	private static final String PEN_STRING = "Enable Pen";
	/**
	 * String for menu.
	 */
	private static final String HOVER_STRING = "Enable Pen Hover";
	/**
	 * String for menu.
	 */
	private static final String FINGER_STRING = "Enable Finger";
	/**
	 * String for menu.
	 */
	private static final String ERASER_STRING = "Enable Eraser";
	/**
	 * String for menu.
	 */
	private static final String LAYER_STRING = "Apply Virtual Layer";
	/**
	 * Menu ID of the Pen.
	 */
	private static final int PEN_MENU_ID = 1001;
	/**
	 * Menu ID of the Hover action.
	 */
	private static final int HOVER_MENU_ID = 1002;
	/**
	 * Menu ID of the Finger.
	 */
	private static final int FINGER_MENU_ID = 1003;
	/**
	 * Menu ID of the Eraser.
	 */
	private static final int ERASER_MENU_ID = 1004;
	/**
	 * Menu ID of the Layer.
	 */
	private static final int LAYER_MENU_ID = 1005;
	/**
	 * Determines tool type.
	 */
	private int mToolType = 0;
	/**
	 * Value to check if button is pressed.
	 */
	private boolean mButton = false;
	/**
	 * Map holding all views, to get their size. The key is the original view, the value is the new view.
	 */
	private HashMap<View, View> mMap;

	/**
	 * Creates the menu which enables using all options.
	 */
	@Override
	public boolean onCreateOptionsMenu(final Menu menu) {

		menu.add(1, PEN_MENU_ID, 1, PEN_STRING);
		menu.add(1, HOVER_MENU_ID, 2, HOVER_STRING);
		menu.add(1, FINGER_MENU_ID, 3, FINGER_STRING);
		menu.add(1, ERASER_MENU_ID, 4, ERASER_STRING);
		menu.add(2, LAYER_MENU_ID, 5, LAYER_STRING);

		menu.setGroupCheckable(1, true, true);

		return super.onCreateOptionsMenu(menu);
	}

	/**
	 * Based on the selected option the tool type changes.
	 */
	@Override
	public boolean onOptionsItemSelected(final MenuItem item) {
		switch (item.getItemId()) {

		case PEN_MENU_ID:
			mToolType = PEN_TOUCH;
			break;
		case HOVER_MENU_ID:
			mToolType = PEN_HOVER;
			break;
		case FINGER_MENU_ID:
			mToolType = FINGER;
			break;
		case ERASER_MENU_ID:
			mToolType = ERASER;
			break;
		/**
		 * Adds the layer on top of all the views.
		 */
		case LAYER_MENU_ID:
			final Window window = getWindow();

			if (window != null) {
				final ViewGroup vg = (ViewGroup) window.getDecorView().getRootView();

				addLayer(vg);

			}
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * Iterates through all views and view groups, adds views to map and checks their size.
	 * 
	 * @param pView
	 *            The view on top of which a layer is put.
	 */
	private void addLayer(final View pView) {

		mMap = new HashMap<View, View>();
		/**
		 * If it's not a view, but a group of views, look deeper.
		 */
		if (pView instanceof ViewGroup) {
			int size = ((ViewGroup) pView).getChildCount();

			for (int i = 0; i < size; i++) {

				final View child = ((ViewGroup) pView).getChildAt(i);
				addLayer(child);
			}
		} else {
			/**
			 * Insert a layer on the view.
			 */
			putLayer(pView);

			View temp = mMap.get(pView);
			if (temp != null) {
				temp.setX(pView.getX());
				temp.setY(pView.getY());
				temp.setLayoutParams(new FrameLayout.LayoutParams(pView.getWidth(), pView.getHeight()));
			}
		}
		pView.invalidate();

	}

	@Override
	public boolean onKeyDown(final int keyCode, final KeyEvent event) {
		if (keyCode == NUMERIC4) {
			/**
			 * If the numeric 4 button on the keyboard is pressed, the mButton value changes. mButton determines whether
			 * the side button is pressed or not.
			 */
			mButton = true;
		}

		return super.onKeyDown(keyCode, event);
	}

	/**
	 * Puts a view on top another view. The view put can intercept all touch events and change them, and dispatch them
	 * to the view underneath.
	 * 
	 * @param pView
	 *            The view on top of which another one will be placed.
	 */
	private void putLayer(final View pView) {
		/**
		 * The view which will be placed on top of other views.
		 */
		final View layerView = new View(ActivityWithSPenLayer.this);

		mMap.put(pView, layerView);

		layerView.setBackgroundColor(Color.TRANSPARENT);
		/**
		 * Intercepts all the touch events, and based on the previous settings changes the tool type.
		 */
		layerView.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(final View v, final MotionEvent event) {

				int pointerCount = event.getPointerCount();
				PointerCoords[] pointerCoords = new PointerCoords[pointerCount];
				PointerProperties[] pointerProperties = new PointerProperties[pointerCount];

				for (int i = 0; i < pointerCount; ++i) {
					pointerCoords[i] = new PointerCoords();
					event.getPointerCoords(i, pointerCoords[i]);

					pointerProperties[i] = new PointerProperties();
					event.getPointerProperties(i, pointerProperties[i]);
					/**
					 * Changes tool type.
					 */
					switch (mToolType) {
					case PEN_TOUCH:
						pointerProperties[i].toolType = MotionEvent.TOOL_TYPE_STYLUS;
						break;
					case ERASER:
						pointerProperties[i].toolType = MotionEvent.TOOL_TYPE_ERASER;
						break;
					case FINGER:
						pointerProperties[i].toolType = MotionEvent.TOOL_TYPE_FINGER;
						break;
					default:
						break;
					}

				}
				/**
				 * Sets the side button on or off.
				 */
				int buttonState;
				if (mButton) {
					buttonState = MotionEvent.BUTTON_SECONDARY;
					mButton = false;
				} else {
					buttonState = MotionEvent.BUTTON_PRIMARY;
				}

				MotionEvent motionEvent;

				/**
				 * Sets hovering on or off.
				 */
				if (mToolType == PEN_HOVER) {
					int actionEvent = 0;
					switch (event.getAction()) {
					case MotionEvent.ACTION_DOWN:
						actionEvent = MotionEvent.ACTION_HOVER_ENTER;
						break;
					case MotionEvent.ACTION_MOVE:
						actionEvent = MotionEvent.ACTION_HOVER_MOVE;
						break;
					case MotionEvent.ACTION_UP:
						actionEvent = MotionEvent.ACTION_HOVER_EXIT;
						break;
					default:
						break;
					}

					/**
					 * If it's a hover event.
					 */
					motionEvent = MotionEvent.obtain(event.getDownTime(), event.getEventTime(), actionEvent,
							event.getPointerCount(), pointerProperties, pointerCoords, event.getMetaState(),
							buttonState, event.getXPrecision(), event.getYPrecision(), event.getDeviceId(),
							event.getEdgeFlags(), event.getSource(), event.getFlags());
					pView.dispatchGenericMotionEvent(motionEvent);
				} else {
					/**
					 * If it's a touch event.
					 */
					motionEvent = MotionEvent.obtain(event.getDownTime(), event.getEventTime(), event.getAction(),
							event.getPointerCount(), pointerProperties, pointerCoords, event.getMetaState(),
							buttonState, event.getXPrecision(), event.getYPrecision(), event.getDeviceId(),
							event.getEdgeFlags(), event.getSource(), event.getFlags());
					pView.dispatchTouchEvent(motionEvent);
				}

				return true;
			}
		});

		ActivityWithSPenLayer.this.addContentView(layerView, pView.getLayoutParams());
	}
}
